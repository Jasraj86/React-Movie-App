export const showMovies = state => ({
    type: 'SHOW',
    state: false,
    
  })