const movielist = (state = [], action) => {
    switch (action.type) {
      case 'SHOW':
        return state.map(
          isLoding =>
          isLoding.state === action.state ? { ...isLoding, isLoding: !state.isLoding } : isLoding
        )
      default:
        return state
    }
  }
  export default movielist