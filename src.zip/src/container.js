import { connect } from 'react-redux'
import { showMovies } from './action'
import App from './App'

const mapStateToProps = state => ({
    movielist: state.id
})

const mapDispatchToProps = dispatch => ({
    showMovies: () => dispatch(showMovies())
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)