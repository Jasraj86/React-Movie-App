import React from 'react';

class App extends React.Component {
 constructor(props) {
    super(props);

    this.state = {
      isLoading:false,
      data: [],
    };
  }

 componentDidMount()
 {
   fetch('https://facebook.github.io/react-native/movies.json')
   .then((response)=>response.json())
   .then((Findresponse)=>{
     console.log(Findresponse.movies)
     this.setState({
      
       data:Findresponse.movies,
     })
     return Findresponse.movies;
   })
   .catch((error) => {
    console.error(error);
    });
 }

 showMovies()
 {
 this.setState({
   isLoading:!this.state.isLoading
 })
 }

   render() {
    
      return (
         <div>
           <button onClick={this.showMovies.bind(this)}>SHOW MOVIES</button>
           {this.state.isLoading?
           <div>
             
              {this.state.data.map((dynamicData,i)=> <MovieContent key = {i} componentData = {dynamicData}/>
              )}
            </div>
            :null
           }
         </div>
      );
     
   }
}

class MovieContent extends React.Component {
  render() {
     return (
        <div>
          <div>Movie:{this.props.componentData.id}</div>
           <div>{this.props.componentData.title}</div>
        </div>
     );
  }
}
export default App;